# Draft API contract (illustrative, not a running server)

Base path: `/api/v1`. All endpoints require HTTPS in production. Use bearer access tokens where authenticated. Responses should include request IDs; market data must include source and timestamps.

- `GET /health` — service health, no sensitive details.
- `GET /market/overview?symbols=...` — licensed, entitled market snapshot with `asOf`, `source`, `isDelayed`, `isStale`.
- `GET /research/briefs` — published research available to the user; draft/unapproved content must never leak.
- `GET /research/briefs/{id}` — versioned report and disclosures.
- `GET /signals` — only properly approved and entitled signals; no endpoint should exist in production until legal/compliance gates are met.
- `GET /tools/{toolId}/snapshot` — tool result plus data provenance and timestamp.
- `GET /academy/courses` — course catalogue.
- `GET /commerce/catalog` — partner inventory, seller identity and price timestamp.
- `POST /subscriptions/checkout` — server-created checkout session; never trust client-supplied price.
- `GET /me/entitlements` — server-computed product access.
- `POST /partner/referrals` — referral attribution only after abuse, consent and contract design.
- `POST /broker/handoff` — later phase only; broker-specific permission and user consent required. It must not silently submit an order.
- `GET /admin/review-queue` — admin-only; role-based and audited.
- `POST /admin/research/{id}/decision` — restricted, dual-control where required, fully audited.

Error shape:
{
  "error": {
    "code": "DATA_NOT_AVAILABLE",
    "message": "Market data is currently unavailable.",
    "requestId": "server-generated-id"
  }
}

Never expose internal stack traces, secrets, broker tokens or personal data in errors.
