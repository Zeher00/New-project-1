# SuperBulls Fintech — production architecture proposal

## 1. Android client
- Kotlin + Jetpack Compose; navigation, view models, repositories and typed API models.
- Client handles presentation and user interaction only. It is not a trusted place for entitlements, permissions, secrets, signals, order rules or pricing.
- Production: add ViewModel/use-case/data layers, Retrofit/OkHttp, Kotlin serialization, secure token storage, crash reporting, accessibility checks and offline/error states.
- Use Play Integrity and device security signals proportionately; do not treat them as the only security control.

## 2. Backend logical services
1. API gateway / BFF: versioned HTTPS API, authentication, rate limits, request validation.
2. Identity and consent: accounts, sessions, MFA, terms acceptance, communication preferences and deletion/export workflows.
3. Market-data adapter: licensed COMEX, MCX and XAUUSD CFD/OTC sources, entitlement checks, timestamps, stale-data detection and normalization.
4. Research pipeline: ingest → validate → normalize → feature store → calculations → AI-assisted research → analyst review → publication.
5. Signal service: versioned methodology, backtests, forward tests, confidence/calibration monitoring, risk limits, kill switch, audit record and publication permissions.
6. Subscription/entitlements: plans, receipts, renewals, cancellation, refund and tax records.
7. Academy: course catalogue, access control, progress and cohort booking.
8. Partner network: referral codes, attribution, KYC/contract status as applicable, disclosure and approved settlement reports.
9. Commerce: seller catalogue, verified inventory, pricing timestamps, order lifecycle, payment provider, shipping, return/refund and reconciliation.
10. Broker adapter (later phase): approved broker-specific authorization, token lifecycle, prefilled order handoff, explicit broker-side final confirmation and full audit trail. No storage of broker passwords.
11. Admin and compliance console: role-based access, dual control for sensitive changes, review queue, content approval, incident log, access history and audit export.
12. Notifications: user opt-in, quiet hours, delivery status, rate limiting and no misleading urgency.
13. Future ETF information module: informational only until a separately approved and properly structured product exists.

## 3. Data layer
- Relational DB for users, subscriptions, partner and order metadata.
- Time-series store for licensed market data, subject to vendor terms.
- Object storage for research documents and course media.
- Queue/event bus for ingestion, research jobs and notifications.
- Cache only for short-lived, licensed, entitlement-appropriate data.
- Encryption in transit and at rest; secrets manager; backup restore tests; retention and deletion jobs.

## 4. Observability and reliability
- Structured logs with PII minimization; metrics, tracing, dashboards and actionable alerts.
- Monitor feed delay, missing ticks, stale quotes, API latency, crash-free sessions, queue lag and notification failures.
- Circuit breakers, bounded retries, idempotency keys, graceful degradation and visible stale-data warnings.
- Separate staging/production, controlled rollout, rollback plan and incident playbooks.
- Establish SLOs with the engineering team and data vendors before claiming “no lag” or uptime guarantees.

## 5. Security baseline
- TLS, short-lived access tokens, refresh-token rotation and server-side authorization.
- No secrets or broker credentials in source, APK resources, analytics or logs.
- RBAC, least privilege, MFA for admins, dual approval for signal/config changes, immutable audit events.
- Dependency scanning, code review, SAST/DAST, penetration testing, API abuse tests and incident response drills.
- Privacy notice, data map, consent, retention, deletion/export and vendor due diligence.

## 6. Compliance gates — not claims of current approval
- Verify the applicable Indian securities rules and the precise activity model with qualified counsel and relevant professionals before launch.
- Research reports and securities recommendations/signals may trigger specific registration, disclosure, recordkeeping and conduct requirements. Do not publish paid actionable signals until the exact model has been reviewed and all required permissions are in place.
- Obtain market-data licences and verify display, redistribution, derived-data and storage rights.
- Broker connectivity requires each broker's current agreement, API permission, security checks and user consent.
- Payment, subscription, refunds, GST, consumer terms, e-commerce, bullion/jewellery fulfilment and privacy obligations need their own review.
- A future ETF requires a separate eligible AMC/issuer, legal structure, exchange and regulatory pathway. Never imply a proposed partnership or approval is already confirmed.

## 7. Vertical-to-phase map
| Vertical | First MVP | Later production work |
|---|---|---|
| 1. Broker ecosystem | Disabled partner directory / architecture | Broker agreements, authorized API, user-confirmed handoff |
| 2. Affiliate / IB / associates | Static programme explainer | Attribution, contracts, disclosures, reconciliation |
| 3. BUY/SELL research signals | Research workflow, no live signals | Licensed feeds, approved research process, validation and audit |
| 4. Software & tools | UI shells and sample visualizations | Live calculations, alerts, subscription entitlement |
| 5. AI research network | Research taxonomy and review queue design | Data pipeline, model monitoring, human review |
| 6. Academy | Course catalogue mockup | CMS, payments, access and progress tracking |
| 7. Gold/silver commerce | Demo catalog shell | Verified sellers, inventory, payments, shipping and returns |
| 8. Future Gold ETF | Clearly labelled concept page | Separate legal/AMC/exchange/regulatory pathway |

## 8. Recommended release gates
A. Clickable design + API contracts.
B. Research MVP with licensed read-only data, secure accounts and admin review.
C. Production readiness review: security, privacy, load, recovery and compliance.
D. Subscriptions and Academy.
E. Partner and commerce modules.
F. Broker integration only after its own sign-off.
G. ETF module only after a separately verified product pathway.
