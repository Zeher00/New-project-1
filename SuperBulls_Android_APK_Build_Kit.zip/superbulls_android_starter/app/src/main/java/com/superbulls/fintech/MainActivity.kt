package com.superbulls.fintech

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Bg = Color(0xFF080909)
private val Panel = Color(0xFF131513)
private val Panel2 = Color(0xFF1B1C18)
private val Gold = Color(0xFFD9B45B)
private val GoldLight = Color(0xFFF3D991)
private val Ink = Color(0xFFF7F4EB)
private val Muted = Color(0xFF9B9B91)
private val Line = Color(0xFF303128)
private val Green = Color(0xFF62D5A0)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { SuperBullsApp() }
    }
}

private data class Vertical(
    val number: String,
    val title: String,
    val subtitle: String,
    val icon: androidx.compose.ui.graphics.vector.ImageVector,
    val status: String,
    val detail: String
)

private val verticals = listOf(
    Vertical("01", "Broker ecosystem", "Multiple broker integrations", Icons.Default.AccountBalance, "PHASED", "Broker discovery and integration planning are shown. No broker API, account link or order placement is connected. Integrate only after partner approval, API permission and security review."),
    Vertical("02", "Partner network", "Affiliate · IB · Associates", Icons.Default.Groups, "PLANNED", "Partner onboarding, referral attribution, consent, disclosures and settlement reporting are planned modules. No affiliate tracking or payouts are active."),
    Vertical("03", "Research & signals", "BUY / SELL / NO TRADE workflow", Icons.Default.ShowChart, "DEMO ONLY", "This prototype has no live signal engine. Production requires licensed market data, model testing, documented methodology, appropriate registration/permissions, analyst review where applicable and audit trails."),
    Vertical("04", "Software & tools", "Charts · alerts · risk tools", Icons.Default.Tune, "PLANNED", "Planned tools include watchlists, volume profile, VWAP/TWAP, option OI/IV, gamma exposure, alerts and risk controls. Data-driven outputs are not connected."),
    Vertical("05", "AI research network", "Institutional-grade intelligence", Icons.Default.Psychology, "PLANNED", "Proposed research pipeline: licensed data ingestion, validation, feature computation, AI-assisted summaries, analyst approval, versioning, audit log and monitoring."),
    Vertical("06", "SuperBulls Academy", "Courses · mentorship · bootcamps", Icons.Default.School, "PLANNED", "Online and offline courses, mentorship cohorts, progress tracking and learning resources. No paid course content or classroom booking is connected."),
    Vertical("07", "Gold & silver commerce", "Bullion · jewellery partners", Icons.Default.Diamond, "CATALOG DEMO", "Partner-led bullion and jewellery commerce is planned. Live inventory, seller verification, pricing, payments, shipping, returns, tax and settlement systems are not connected."),
    Vertical("08", "Future Gold ETF", "Potential AMC / exchange pathway", Icons.Default.AccountBalanceWallet, "FUTURE CONCEPT", "A possible SuperBulls-named Gold ETF is only a future concept. No AMC partnership, product launch, exchange listing or approval is represented as existing.")
)

@Composable
fun SuperBullsApp() {
    var selected by remember { mutableStateOf("Home") }
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Gold, onPrimary = Color(0xFF17130A),
            background = Bg, surface = Panel, onSurface = Ink,
            secondary = GoldLight, onBackground = Ink
        )
    ) {
        Scaffold(
            containerColor = Bg,
            bottomBar = { BottomNavigation(selected) { selected = it } }
        ) { padding ->
            Column(
                Modifier.fillMaxSize().padding(padding)
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 16.dp)
            ) {
                Spacer(Modifier.height(18.dp))
                Header()
                Spacer(Modifier.height(24.dp))
                when (selected) {
                    "Home" -> HomeScreen { selected = it }
                    "Research" -> ResearchScreen()
                    "Business" -> BusinessScreen()
                    "Learn" -> AcademyScreen()
                    "Profile" -> ProfileScreen()
                }
                Spacer(Modifier.height(24.dp))
                Text(
                    "DEMO PROTOTYPE · NOT LIVE MARKET DATA · NO EXECUTION",
                    color = Muted, fontSize = 9.sp, letterSpacing = 1.sp,
                    modifier = Modifier.fillMaxWidth().padding(bottom = 10.dp)
                )
            }
        }
    }
}

@Composable
private fun Header() {
    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
        Box(
            Modifier.size(46.dp).background(Panel2, RoundedCornerShape(14.dp)),
            contentAlignment = Alignment.Center
        ) {
            Text("SB", color = Gold, fontWeight = FontWeight.Black, fontSize = 19.sp)
        }
        Spacer(Modifier.width(11.dp))
        Column(Modifier.weight(1f)) {
            Text("SUPERBULLS", fontWeight = FontWeight.ExtraBold, letterSpacing = 1.8.sp, fontSize = 16.sp)
            Text("FINTECH INTELLIGENCE", color = Gold, fontSize = 9.sp, letterSpacing = 2.sp)
        }
        Box(
            Modifier.size(38.dp).background(Panel2, CircleShape),
            contentAlignment = Alignment.Center
        ) { Icon(Icons.Default.PersonOutline, null, tint = Gold) }
    }
}

@Composable
private fun HomeScreen(onNavigate: (String) -> Unit) {
    Text("INSTITUTIONAL-GRADE INTELLIGENCE", color = Gold, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
    Spacer(Modifier.height(7.dp))
    Text("Trade smarter.\nWith SuperBulls.", fontSize = 29.sp, lineHeight = 34.sp, fontWeight = FontWeight.Bold)
    Spacer(Modifier.height(5.dp))
    Text("Research with purpose. Invest with discipline. Manage risk.", color = Muted, fontSize = 12.sp)
    Spacer(Modifier.height(20.dp))
    Row(horizontalArrangement = Arrangement.spacedBy(9.dp)) {
        DemoMarket("GOLD · DEMO", "₹72,485", "+0.42%", Modifier.weight(1f))
        DemoMarket("SILVER · DEMO", "₹89,240", "−0.18%", Modifier.weight(1f))
    }
    Spacer(Modifier.height(9.dp))
    DemoMarket("XAUUSD REFERENCE · DEMO", "$2,748.60", "Illustrative only", Modifier.fillMaxWidth())
    Spacer(Modifier.height(16.dp))
    Surface(color = Panel, shape = RoundedCornerShape(18.dp), border = BorderStroke(1.dp, Line)) {
        Column(Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("AI Research Brief", fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                StatusTag("NOT CONNECTED")
            }
            Spacer(Modifier.height(9.dp))
            Text("Live data connection required", color = GoldLight, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(5.dp))
            Text("No actionable signal generated. The live feed, research engine and compliance review are not connected in this prototype.", color = Muted, fontSize = 12.sp)
            Spacer(Modifier.height(14.dp))
            Button(
                onClick = { onNavigate("Research") },
                colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Color(0xFF17130A)),
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp)
            ) { Text("Explore Gold Research", fontWeight = FontWeight.Bold) }
        }
    }
    Spacer(Modifier.height(20.dp))
    SectionTitle("Your SuperBulls platform", "ALL 8 VERTICALS")
    Spacer(Modifier.height(10.dp))
    verticals.forEach { v ->
        VerticalCard(v) { onNavigate(if (v.number == "06") "Learn" else if (v.number == "03" || v.number == "05") "Research" else "Business") }
        Spacer(Modifier.height(9.dp))
    }
    Spacer(Modifier.height(5.dp))
    SectionTitle("Reliability comes first", "FOUNDATION")
    Spacer(Modifier.height(9.dp))
    InfoCard("Secure architecture", "Authentication, backend authorization, observability, encrypted data and disaster recovery must be implemented before production.", Icons.Default.Security)
    Spacer(Modifier.height(9.dp))
    InfoCard("Broker handoff later", "Research-first launch. Broker integration stays disabled until partner, API, security and compliance gates are cleared.", Icons.Default.Link)
}

@Composable
private fun DemoMarket(label: String, price: String, change: String, modifier: Modifier = Modifier) {
    Surface(modifier, color = Panel, shape = RoundedCornerShape(15.dp), border = BorderStroke(1.dp, Line)) {
        Column(Modifier.padding(13.dp)) {
            Text(label, color = Muted, fontSize = 9.sp, letterSpacing = .7.sp)
            Spacer(Modifier.height(6.dp))
            Text(price, fontWeight = FontWeight.Bold, fontSize = 19.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Spacer(Modifier.height(3.dp))
            Text(change, color = if (change.startsWith("+")) Green else Gold, fontSize = 10.sp)
        }
    }
}

@Composable
private fun SectionTitle(title: String, label: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(title, fontSize = 15.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
        Text(label, color = Gold, fontSize = 9.sp, letterSpacing = .8.sp)
    }
}

@Composable
private fun VerticalCard(v: Vertical, onClick: () -> Unit) {
    Surface(
        color = Panel, shape = RoundedCornerShape(15.dp),
        border = BorderStroke(1.dp, Line),
        modifier = Modifier.fillMaxWidth().clickable(onClick = onClick)
    ) {
        Row(Modifier.padding(13.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(43.dp).background(Panel2, RoundedCornerShape(12.dp)), contentAlignment = Alignment.Center) {
                Icon(v.icon, null, tint = Gold, modifier = Modifier.size(22.dp))
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text("${v.number}  ${v.title}", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                Spacer(Modifier.height(3.dp))
                Text(v.subtitle, color = Muted, fontSize = 10.sp)
            }
            Spacer(Modifier.width(5.dp))
            Icon(Icons.Default.ChevronRight, null, tint = Gold)
        }
    }
}

@Composable
private fun StatusTag(text: String) {
    Surface(color = Color(0xFF2A2416), shape = RoundedCornerShape(50), border = BorderStroke(1.dp, Color(0xFF5A4927))) {
        Text(text, color = GoldLight, fontSize = 8.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp))
    }
}

@Composable
private fun InfoCard(title: String, body: String, icon: androidx.compose.ui.graphics.vector.ImageVector) {
    Surface(color = Panel, shape = RoundedCornerShape(15.dp), border = BorderStroke(1.dp, Line)) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.Top) {
            Icon(icon, null, tint = Gold, modifier = Modifier.size(23.dp))
            Spacer(Modifier.width(11.dp))
            Column {
                Text(title, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                Spacer(Modifier.height(4.dp))
                Text(body, color = Muted, fontSize = 11.sp)
            }
        }
    }
}

@Composable
private fun ResearchScreen() {
    SectionTitle("Research desk", "READ-ONLY MVP")
    Spacer(Modifier.height(8.dp))
    Text("Global gold → Indian gold", color = Gold, fontSize = 12.sp)
    Spacer(Modifier.height(14.dp))
    InfoCard("Signal workflow", "Data validation → feature calculation → AI-assisted research → analyst review → publication → audit log. No signal is published by this demo.", Icons.Default.Psychology)
    Spacer(Modifier.height(10.dp))
    val rows = listOf(
        "DXY & US dollar" to "DATA REQUIRED",
        "Nominal / real US yields" to "DATA REQUIRED",
        "COMEX futures & COT" to "DATA REQUIRED",
        "ETF holdings / flows" to "DATA REQUIRED",
        "MCX–COMEX premium" to "CALCULATION",
        "Options OI / IV / gamma" to "LICENSE REQUIRED",
        "USD/INR & physical demand" to "DATA REQUIRED",
        "Risk controls & invalidation" to "DESIGN REQUIRED"
    )
    Surface(color = Panel, shape = RoundedCornerShape(16.dp), border = BorderStroke(1.dp, Line)) {
        Column(Modifier.padding(horizontal = 14.dp)) {
            rows.forEachIndexed { i, pair ->
                Row(Modifier.fillMaxWidth().padding(vertical = 13.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(pair.first, fontSize = 12.sp, modifier = Modifier.weight(1f))
                    Text(pair.second, color = Gold, fontSize = 8.sp, fontWeight = FontWeight.Bold)
                }
                if (i != rows.lastIndex) HorizontalDivider(color = Line)
            }
        }
    }
    Spacer(Modifier.height(12.dp))
    Text("Prices, technical levels and signal outcomes are not live or validated. Do not use this screen to make trading decisions.", color = Muted, fontSize = 11.sp)
}

@Composable
private fun BusinessScreen() {
    SectionTitle("Business verticals", "ROADMAP")
    Spacer(Modifier.height(7.dp))
    Text("The eight verticals are represented as roadmap modules. A tile is not proof of a live service, approval or partner contract.", color = Muted, fontSize = 11.sp)
    Spacer(Modifier.height(13.dp))
    verticals.forEach { v ->
        Surface(color = Panel, shape = RoundedCornerShape(15.dp), border = BorderStroke(1.dp, Line)) {
            Column(Modifier.padding(14.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(v.number, color = Gold, fontSize = 11.sp, fontWeight = FontWeight.ExtraBold)
                    Spacer(Modifier.width(9.dp))
                    Text(v.title, fontSize = 13.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                    StatusTag(v.status)
                }
                Spacer(Modifier.height(8.dp))
                Text(v.detail, color = Muted, fontSize = 11.sp)
            }
        }
        Spacer(Modifier.height(9.dp))
    }
}

@Composable
private fun AcademyScreen() {
    SectionTitle("SuperBulls Academy", "PLANNED")
    Spacer(Modifier.height(8.dp))
    Text("Education · Empowerment · Innovation", color = Gold, fontSize = 12.sp)
    Spacer(Modifier.height(14.dp))
    listOf(
        Triple("Gold market foundations", "COMEX, MCX, XAUUSD and macro drivers", Icons.Default.AutoStories),
        Triple("Risk management", "Position sizing, invalidation and discipline", Icons.Default.Shield),
        Triple("Institutional tools", "Volume profile, order flow and options basics", Icons.Default.ShowChart),
        Triple("Mentorship & bootcamps", "Online and offline learning cohorts", Icons.Default.Groups)
    ).forEach { item ->
        InfoCard(item.first, item.second, item.third)
        Spacer(Modifier.height(9.dp))
    }
    Text("Course content, enrolment, payment and progress tracking are not connected in this prototype.", color = Muted, fontSize = 11.sp)
}

@Composable
private fun ProfileScreen() {
    SectionTitle("Account & preferences", "PROTOTYPE")
    Spacer(Modifier.height(12.dp))
    InfoCard("Sign-in not enabled", "A production release needs secure account creation, identity verification where appropriate, session management, consent records and account recovery.", Icons.Default.Lock)
    Spacer(Modifier.height(9.dp))
    InfoCard("Privacy & security", "No personal account or broker credentials are collected by this sample app. Production data collection requires a privacy notice, retention policy and access controls.", Icons.Default.Security)
    Spacer(Modifier.height(9.dp))
    InfoCard("Compliance gates", "Research/signal publishing, broker integrations, payments, e-commerce and any future ETF must each pass their own legal, regulatory and operational reviews.", Icons.Default.Gavel)
    Spacer(Modifier.height(9.dp))
    Text("Trade Smarter. Trade with SuperBulls.", color = Gold, fontWeight = FontWeight.Bold, fontSize = 13.sp)
}

@Composable
private fun BottomNavigation(selected: String, onSelect: (String) -> Unit) {
    val items = listOf(
        "Home" to Icons.Default.Home,
        "Research" to Icons.Default.ShowChart,
        "Business" to Icons.Default.GridView,
        "Learn" to Icons.Default.School,
        "Profile" to Icons.Default.PersonOutline
    )
    NavigationBar(containerColor = Color(0xFF101110), contentColor = Gold) {
        items.forEach { (name, icon) ->
            NavigationBarItem(
                selected = selected == name,
                onClick = { onSelect(name) },
                icon = { Icon(icon, contentDescription = name) },
                label = { Text(name, fontSize = 9.sp) },
                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = Gold,
                    selectedTextColor = Gold,
                    indicatorColor = Color(0xFF302719),
                    unselectedIconColor = Muted,
                    unselectedTextColor = Muted
                )
            )
        }
    }
}
